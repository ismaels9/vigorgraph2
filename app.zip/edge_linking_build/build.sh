c++ -O3 -Wall -shared -std=c++11 -fPIC $(python3 -m pybind11 --includes) $(pkg-config --cflags --libs opencv) edge_linking.cpp -o "../example$(python3-config --extension-suffix)"
